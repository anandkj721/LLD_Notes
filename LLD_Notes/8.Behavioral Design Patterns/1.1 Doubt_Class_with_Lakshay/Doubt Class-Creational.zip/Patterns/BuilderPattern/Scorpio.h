#ifndef SCORPIO_H
#define SCORPIO_H

#include "ICar.h"

class Scorpio : public ICar
{
public:
    // Additional Scorpio-specific methods can be declared here
};

#endif
