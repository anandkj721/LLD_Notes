#ifndef ICAR_H
#define ICAR_H

class ICar
{
public:
    virtual ~ICar() {}
};

#endif
