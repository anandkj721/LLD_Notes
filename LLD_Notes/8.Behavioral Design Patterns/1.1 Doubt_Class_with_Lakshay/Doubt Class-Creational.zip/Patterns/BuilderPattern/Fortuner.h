#ifndef FORTUNER_H
#define FORTUNER_H

#include "ICar.h"

class Fortuner : public ICar
{
public:
    // Additional Fortuner-specific methods can be declared here
};

#endif
