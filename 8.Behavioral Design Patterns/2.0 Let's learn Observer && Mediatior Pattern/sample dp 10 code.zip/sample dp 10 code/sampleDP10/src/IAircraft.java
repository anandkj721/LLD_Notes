public interface IAircraft {

    public void land();

}
