public interface IAircraft {

    void fly();

    void land();
}
