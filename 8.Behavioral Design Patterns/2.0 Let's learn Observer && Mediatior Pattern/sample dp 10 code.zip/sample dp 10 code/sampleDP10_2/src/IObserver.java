public interface IObserver {

    void proceed(Object newState);

}
