public interface IAircraft {
}
