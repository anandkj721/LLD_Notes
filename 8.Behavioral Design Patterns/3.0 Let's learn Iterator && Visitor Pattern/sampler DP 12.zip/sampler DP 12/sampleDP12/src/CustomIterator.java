public interface CustomIterator {

    IAircraft next();

    boolean hasNext();

}
