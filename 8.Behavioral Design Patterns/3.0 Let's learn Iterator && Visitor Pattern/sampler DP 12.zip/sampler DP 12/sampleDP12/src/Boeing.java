public class Boeing implements IAircraft{
}
