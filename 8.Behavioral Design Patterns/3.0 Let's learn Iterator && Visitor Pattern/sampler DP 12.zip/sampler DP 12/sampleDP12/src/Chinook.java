public class Chinook implements IAircraft{
}
